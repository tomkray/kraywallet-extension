
# 🎨 MyWallet - Design System Documentation

## ✨ Overview

Professional Bitcoin wallet extension with modern, minimalist dark theme.
Inspired by: Xverse, MetaMask, Phantom, Apple Design Guidelines.

---

## 🎯 Design Principles

1. **Minimalism** - Clean, focused interfaces
2. **Consistency** - Unified spacing, colors, typography
3. **Accessibility** - Clear hierarchy, readable text
4. **Performance** - Smooth animations, instant feedback
5. **Professional** - Enterprise-grade polish

---

## 🎨 Color Palette

### Background
- Primary: `#000000` (True black)
- Secondary: `#111111` (Cards, inputs)
- Tertiary: `#1a1a1a` (Hover states)

### Text
- Primary: `#ffffff` (Main text)
- Secondary: `#888888` (Labels)
- Tertiary: `#666666` (Placeholders)

### Borders
- Default: `#1a1a1a`
- Hover: `#2a2a2a`

### Accent
- Primary: `#ffffff` (Buttons, highlights)
- Danger: `#ff3b30` (Warnings, delete)
- Success: `#34c759` (Success states)
- Warning: `#ff9500` (Cautions)

---

## 📐 Spacing System

```
xs:  4px   (Micro spacing)
sm:  8px   (Tight elements)
md:  12px  (Default gap)
lg:  16px  (Section padding)
xl:  20px  (Page padding)
2xl: 24px  (Large sections)
3xl: 32px  (Hero sections)
```

---

## 🔲 Border Radius

```
sm:   8px   (Small elements)
md:   12px  (Cards, buttons)
lg:   16px  (Large cards)
full: 9999px (Pills, avatars)
```

---

## 📝 Typography

### Font Families
- **Primary**: SF Pro Display, system-ui
- **Monospace**: SF Mono, Courier New

### Text Sizes
- Hero: 48px (Balance)
- H1: 32px (Welcome)
- H2: 20px (Screen titles)
- Body: 15px (Main text)
- Small: 13px (Labels)
- Tiny: 12px (Captions)

---

## 🎭 Component Structure

### Screen Layout
```
┌─────────────────────────────┐
│  [Back] Title         [Icon]│ ← Header (60px)
├─────────────────────────────┤
│                             │
│  Content Area               │ ← Flex: 1
│  (Form, List, etc)          │
│                             │
├─────────────────────────────┤
│  [Primary Button]           │ ← Footer
└─────────────────────────────┘
```

### Button Hierarchy
1. **Primary** - Main actions (White bg)
2. **Secondary** - Alternative actions (Dark bg)
3. **Icon** - Utility actions (Icon only)

### Card Structure
```
┌─────────────────┐
│   [Preview]     │ ← 140px height
├─────────────────┤
│ Title           │
│ Subtitle        │ ← 12px padding
│ Metadata        │
└─────────────────┘
```

---

## 🎬 Animations

### Timing Functions
- Fast: `0.15s` (Micro interactions)
- Base: `0.2s` (Default)
- Slow: `0.3s` (Page transitions)

### Easing
```css
cubic-bezier(0.4, 0, 0.2, 1)
```

### Common Patterns
- **Hover**: `translateY(-1px)` + shadow
- **Click**: Scale down briefly
- **Loading**: Rotate 360deg infinite

---

## 📱 Screen Organization

### 1. Welcome Screen
- Large logo (80px)
- Title + subtitle
- 2 main actions
- 3 feature badges

### 2. Create/Restore Wallet
- Back button (top-left)
- Title (centered)
- Form fields
- Primary CTA (bottom)

### 3. Main Wallet
- Top bar (network + settings)
- Account card
- Large balance display
- 2 action buttons (Send/Receive)
- 3 tabs (Ordinals/Runes/Activity)
- Grid content (2 columns)

### 4. Settings
- Back button
- Sectioned list
- Grouped options
- Danger zone (separate)

---

## 🎯 Best Practices

### ✅ Do
- Use CSS variables for consistency
- Follow 8px grid system
- Keep hover states subtle
- Use loading states
- Provide visual feedback

### ❌ Don't
- Mix spacing values
- Use inconsistent colors
- Skip transitions
- Forget empty states
- Over-animate

---

## 📊 Component Checklist

- [x] Screens have proper headers
- [x] Buttons follow hierarchy
- [x] Forms have consistent styling
- [x] Cards have hover states
- [x] Loading states exist
- [x] Empty states defined
- [x] Notifications styled
- [x] Icons are consistent
- [x] Spacing follows system
- [x] Colors use variables

---

## 🚀 Performance

- CSS variables for theming
- Hardware-accelerated transforms
- Optimized animations (transform/opacity)
- Minimal repaints
- Efficient selectors

---

## 📐 Grid System

### Main Grid (Ordinals/Runes)
```css
display: grid;
grid-template-columns: repeat(2, 1fr);
gap: 12px;
```

### Form Grid
```css
display: flex;
flex-direction: column;
gap: 20px;
```

---

## 🎨 Shadows

- **Small**: `0 2px 8px rgba(0,0,0,0.2)`
- **Medium**: `0 4px 16px rgba(0,0,0,0.3)`
- **Large**: `0 8px 32px rgba(0,0,0,0.4)`

---

## 🔄 State Management

### Interactive States
1. **Default** - Base appearance
2. **Hover** - Subtle highlight
3. **Active/Focus** - Strong highlight
4. **Disabled** - 40% opacity

### Visual Feedback
- Buttons: Y-translate + shadow
- Cards: Y-translate + shadow
- Inputs: Border color change
- Icons: Scale or rotate

---

## 📱 Responsive (Future)

Currently: 375px fixed width
Future: Responsive breakpoints

```
sm: 320px  (Mobile)
md: 375px  (Current)
lg: 480px  (Tablet)
```

---

## 🎯 Accessibility

- Semantic HTML
- Proper ARIA labels
- Keyboard navigation
- Focus indicators
- Color contrast (WCAG AA)

---

## 🔧 Development

### File Structure
```
kraywallet-extension/
├── popup/
│   ├── popup.html  (Structure)
│   ├── popup.css   (Styles)
│   └── popup.js    (Logic)
└── DESIGN_SYSTEM.md (This file)
```

### CSS Organization
1. Variables
2. Reset & Base
3. Layout
4. Components
5. Utilities

---

## 📈 Future Improvements

- [ ] Light mode support
- [ ] Custom themes
- [ ] Animation preferences
- [ ] Compact/expanded views
- [ ] More color schemes

---

**Version**: 2.0.0
**Last Updated**: 2025-10-17
**Maintained by**: MyWallet Team

