# 🔐 MyWallet Verified Runes

## ⚠️ ACESSO RESTRITO - SOMENTE ADMIN

O badge de verificado (✓) é uma **feature exclusiva da MyWallet** para garantir a autenticidade das Runes.

**SOMENTE O ADMINISTRADOR** pode adicionar runes à lista de verificadas.

---

## 🎯 Runes Atualmente Verificadas

```javascript
const VERIFIED_RUNES = [
    'DOG•GO•TO•THE•MOON',  // ✅ Verificada
    'LOBO•THE•WOLF•PUP'    // ✅ Verificada
];
```

---

## 🔧 Como Adicionar uma Nova Rune (ADMIN ONLY)

1. Abra o arquivo: **`/kraywallet-extension/popup/popup.js`**
2. Encontre a constante `VERIFIED_RUNES` (linha ~2228)
3. Adicione o nome **EXATO** da rune:

```javascript
const VERIFIED_RUNES = [
    'DOG•GO•TO•THE•MOON',
    'LOBO•THE•WOLF•PUP',
    'NOVA•RUNE•VERIFICADA'  // ← Adicione aqui
];
```

4. Salve o arquivo
5. Recarregue a extension (Ctrl+R ou Cmd+R)

---

## ⚠️ REGRAS IMPORTANTES

- ✅ Nome da rune deve ser **EXATO** (case-sensitive)
- ✅ Use o caractere `•` (bullet) correto
- ✅ Verifique a autenticidade antes de adicionar
- ❌ **NÃO** adicionar runes não verificadas
- ❌ **NÃO** compartilhar acesso de admin

---

## 🎨 Visual do Badge

- **Posição:** Canto superior direito do thumbnail
- **Tamanho:** 18x18px (discreto)
- **Cor:** Azul gradiente (#3b82f6 → #2563eb)
- **Ícone:** ✓ branco
- **Efeito:** Pulse sutil (animação de brilho)
- **Tooltip:** "Verified by MyWallet"

---

## 📊 Processo de Verificação (Recomendado)

Antes de adicionar uma rune como verificada, considere:

1. ✅ Verificar o **parent inscription** da rune
2. ✅ Confirmar a **autenticidade** no ORD Explorer
3. ✅ Checar o **Rune ID** oficial
4. ✅ Verificar a **comunidade** e projeto oficial
5. ✅ Confirmar que não é **scam** ou **fake**

---

**MyWallet Feature** - Sistema de Verificação de Runes v1.0  
**Status:** Ativo | **Acesso:** Admin Only

