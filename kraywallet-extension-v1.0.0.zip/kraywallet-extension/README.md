# 🪙 KrayWallet - Bitcoin Ordinals & Runes Wallet

A powerful Chrome extension wallet for Bitcoin, Ordinals, and Runes.

## ✨ Features

- 🔐 **Secure BIP39 HD Wallet** (Taproot addresses)
- 🖼️ **Ordinals Support** (Inscriptions with thumbnails)
- 🪙 **Runes Support** (Full protocol support with automatic parent detection)
- 💰 **Bitcoin Transactions**
- 📊 **Activity Tracking** (Real-time + mempool)
- 🔄 **Send & Receive** (Inscriptions and Runes)
- 🎨 **Beautiful UI** (Modern and responsive)

## 🚀 Technology

- **Bitcoin**: Taproot (BIP86)
- **Ordinals**: Full protocol support
- **Runes**: Runestone protocol
- **Backend**: QuickNode (100% cloud)
- **Security**: Encrypted local storage

## 📦 Installation

### From Source:

1. Clone repository
2. Open Chrome: `chrome://extensions/`
3. Enable "Developer mode"
4. Click "Load unpacked"
5. Select `kraywallet-extension` folder

## 🔧 Configuration

No configuration needed! Just install and create your wallet.

## 🛡️ Security

- ✅ Mnemonic encrypted with AES-256-GCM
- ✅ Private keys never leave your device
- ✅ Auto-lock after inactivity
- ✅ Secure UTXO filtering (protects inscriptions/runes)

## 📝 License

MIT

## 🌐 Links

- Website: https://kraywallet.com
- Documentation: https://docs.kraywallet.com
- Support: https://github.com/tomkray/kraywallet-extension/issues

---

**Made with ❤️ for the Bitcoin Ordinals community**
