
# 🔧 TROUBLESHOOTING - MyWallet Extension

## ❌ Erro ao Criar Wallet

### Sintoma:
Erro quando digita a senha na tela de criar wallet.

### Possíveis Causas:

1. **Senha muito curta**
   - ✅ Solução: Use pelo menos 6 caracteres

2. **Lista BIP39 incompleta**
   - ✅ CORRIGIDO: Lista expandida para 256 palavras

3. **Erro de criptografia**
   - ✅ CORRIGIDO: Tratamento de erros melhorado

### Como Testar Agora:

1. Remova a extensão antiga:
   ```
   chrome://extensions/ → Remover MyWallet
   ```

2. Recarregue a extensão:
   ```
   chrome://extensions/ → Carregar sem compactação
   Selecione: kraywallet-extension/
   ```

3. Tente criar a wallet novamente:
   - Escolha: 12 ou 24 palavras
   - Digite senha com **mínimo 6 caracteres**
   - Confirme a senha
   - Clique em "Create Wallet"

4. Verifique o console (F12):
   - Vá em "Service Worker" → Console
   - Deve aparecer:
     ```
     🎲 Generating 12-word mnemonic...
     ✅ Entropy generated: 16 bytes
     ✅ Mnemonic generated: 12 words
     🔑 Generating REAL wallet with BIP39...
     ✅ Real mnemonic generated
     ✅ Real Taproot address derived: bc1p...
     🔐 Encrypting wallet data...
     ✅ Data encrypted successfully
     ```

---

## 🐛 Outros Erros Comuns

### 1. "Extension context invalidated"
**Solução:**
- Recarregue a extensão em `chrome://extensions/`
- Feche e abra novamente o popup

### 2. "Storage quota exceeded"
**Solução:**
- Vá em Settings → Reset Wallet
- Isso limpa o storage

### 3. "Failed to fetch balance"
**Solução:**
- Verifique conexão com internet
- API da Mempool.space pode estar offline
- Vai usar dados mock como fallback

### 4. Tabs não aparecem
**Solução:**
- Certifique que wallet está criada
- Reabra o popup
- Verifique console por erros

---

## 📊 Logs Úteis

### Ver logs do Background Script:
1. `chrome://extensions/`
2. Encontre "MyWallet"
3. Clique em "Service Worker"
4. Veja o console

### Ver logs do Popup:
1. Abra o popup da extensão
2. Clique direito → "Inspecionar"
3. Veja o console

---

## 🔄 Reset Completo

Se nada funcionar:

1. Remova a extensão
2. Limpe storage:
   ```javascript
   // No console do browser:
   chrome.storage.local.clear()
   ```
3. Recarregue a extensão
4. Crie nova wallet

---

## ✅ Checklist de Funcionamento

- [ ] Lista BIP39 tem 256 palavras ✅
- [ ] Senha aceita 6+ caracteres ✅
- [ ] Criptografia com logs ✅
- [ ] Tabs Ordinals/Runes aparecem ✅
- [ ] Balance carrega (ou usa mock) ✅
- [ ] Settings funciona ✅

